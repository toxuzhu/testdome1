<?php
return array(
	//'配置项'=>'配置值'
    'now_version'=>2.3
);
