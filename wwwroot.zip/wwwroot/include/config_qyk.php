<?php
/*-------------通行证API设置，非青云客旗下网站不需要设置，请不要删除以下项目--------------*/
define('setup_qyk_api','http://user.qingyunke.com/');
define('setup_qyk_appid',0);
define('setup_qyk_appsecret','');
?>