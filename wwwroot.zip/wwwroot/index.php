<?php
$tczruntime=microtime(true);
include('include/class_temp.php');
$qyk=new qyk();
$qyk->createHTML();
?>