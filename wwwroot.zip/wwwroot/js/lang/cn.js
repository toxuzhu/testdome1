var qyklang={
"sys":{
	"nodata":"没有数据"
	},
"win":{
	"title":"系统提示",
	"btn_ok":"确 定",
	"photobox":"图片："
	},
"search":{
	"error":"请输入关键字再搜索",
	"error2":"请选择要搜索栏目",
	"error3":"错误的搜索字段名"
	},
"tool":{
	"customer":"QQ咨询",
	"skype":"Skype咨询",
	"phone":"咨询电话",
	"weixin":"官方微信",
	"feedback":"在线留言",
	"close":"关闭"
	},
"feedback":{
	"open":{
		"title":"在线留言",
		"name":"您的称呼",
		"email":"邮箱地址",
		"email_tip":"邮箱地址、联系电话至少填写一项",
		"tel":"联系电话",
		"upload":"上传附件",
		"upload_tip":"仅支持rar，zip，doc类型文件",
		"upload_start":"选择文件",
		"upload_cancel":"已选择文件，点击取消",
		"content":"留言内容",
		"btn1":"提交留言",
		"btn2":"取 消"
		},
	"send":{
		"name":"请输入您的称呼",
		"email":"邮箱地址、联系电话至少填写一项",
		"content":"请输入留言内容",
		"load":"正在提交留言，请稍候...",
		"success":"您的留言内容已提交，我们会尽快给您回复！",
		"btn":"好 的"
		}
	},
"comment":{
	"start":{
		"error":"列表载入失败"
		},
	"send":{
		"text":"来了就说两句呗...",
		"name":"称呼：",
		"face":"表情",
		"btn":"发表评论",
		"btn2":"发表留言",
		"load":"正在提交，请稍候",
		"success":"提交成功",
		"success_no":"已提交成功，请等待管理员审核",
		"reload":"正在刷新列表...",
		"error1":"请输入内容",
		"error2":"请发表有意义的内容",
		"error3":"内容太长了："
		},
	"list":{
		"title":"网友评论列表",
		"tips1":"共有 ",
		"tips2":" 条评论"
		},
	"list2":{
		"title":"网友留言列表",
		"tips1":"共有 ",
		"tips2":" 条留言"
		}
	},
"expmood":{
	"text":"赞一个,震惊,鄙视,呵呵,打酱油"
	},
"banner":{
	"nodata":"暂无数据，推荐尺寸（宽x高）："
	}
};