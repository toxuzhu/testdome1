	</div>
	<div class="footer">
		<div class="copy">Powered by <a href="http://cms.qingyunke.com" title="青云客CMS" target=_blank>QYKCMS 4.0</a></div>
	</div>
</div>
</body>
</html>