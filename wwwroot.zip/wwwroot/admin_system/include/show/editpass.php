<?php
$res='<div class="win_ajax ajax_edit">
<table id="admin_show_1" class="ajax_tablist" cellpadding="12" cellspacing="1">
<tr><td class="td6_1">当前帐号</td><td class="td6_2"><input type="text" class="inp_no" value="'.$tcz['admin'].'" readonly></td></tr>
<tr><td class="td6_1">旧的密码</td><td class="td6_2"><input type="password" class="inp" id="old_pass"></td></tr>
<tr><td class="td6_1">新的密码</td><td class="td6_2"><input type="password" class="inp" id="user_pass"></td></tr>
<tr><td class="td6_1">确认新密码</td><td class="td6_2"><input type="password" class="inp" id="user_pass2"></td></tr>
</table></div>';